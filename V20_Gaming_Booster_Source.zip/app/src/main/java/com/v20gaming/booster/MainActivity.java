package com.v20gaming.booster;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final List<ResolveInfo> launchableApps = new ArrayList<>();
    private Spinner appSpinner;
    private TextView deviceInfo;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        loadApps();
        showDeviceInfo();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(24));
        root.setBackgroundColor(0xFFF3F6FA);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("V20 GAMING BOOSTER");
        title.setTextSize(23);
        title.setTextColor(0xFF102A43);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, params(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("A simple gaming companion for your Vivo V20");
        subtitle.setTextSize(14);
        subtitle.setTextColor(0xFF526579);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(22));
        root.addView(subtitle);

        TextView chooseLabel = label("Choose your game");
        root.addView(chooseLabel);
        appSpinner = new Spinner(this);
        root.addView(appSpinner, params(-1, dp(52)));

        Button launch = button("LAUNCH SELECTED GAME");
        root.addView(launch, params(-1, dp(54)));
        launch.setOnClickListener(v -> launchSelected());

        root.addView(label("Before you play"));
        root.addView(info("1. Close games and heavy apps you are not using."));
        root.addView(info("2. Turn on your phone's built-in Ultra Game Mode / Game Assistant if available."));
        root.addView(info("3. Keep the phone cool. Remove a thick case if it heats up."));
        root.addView(info("4. Avoid playing while charging if the phone becomes hot."));
        root.addView(info("5. In the game, lower shadows and effects if those settings are available."));

        root.addView(label("Quick settings"));
        Button battery = button("OPEN BATTERY SETTINGS");
        root.addView(battery, params(-1, dp(48)));
        battery.setOnClickListener(v -> openSettings(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));

        Button appSettings = button("OPEN APP SETTINGS");
        root.addView(appSettings, params(-1, dp(48)));
        appSettings.setOnClickListener(v -> openSettings(new Intent(Settings.ACTION_APPLICATION_SETTINGS)));

        deviceInfo = new TextView(this);
        deviceInfo.setTextSize(12);
        deviceInfo.setTextColor(0xFF526579);
        deviceInfo.setPadding(0, dp(22), 0, dp(8));
        root.addView(deviceInfo);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("Honest performance note: this app does not overclock the GPU, add RAM, change game graphics, or guarantee higher FPS. Android does not allow ordinary apps to force those changes. It helps you launch your game and follow safe setup steps.");
        disclaimer.setTextSize(12);
        disclaimer.setTextColor(0xFF6B4F1D);
        disclaimer.setBackgroundColor(0xFFFFF3D6);
        disclaimer.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(disclaimer);
        setContentView(scroll);
    }

    private void loadApps() {
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        apps.sort((a,b) -> String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        launchableApps.clear();
        List<String> labels = new ArrayList<>();
        int preferred = -1;
        for (ResolveInfo app : apps) {
            if (app.activityInfo.packageName.equals(getPackageName())) continue;
            launchableApps.add(app);
            String name = String.valueOf(app.loadLabel(pm));
            labels.add(name);
            if (name.toLowerCase().contains("cricket") && name.toLowerCase().contains("007")) preferred = labels.size()-1;
        }
        if (labels.isEmpty()) labels.add("No launchable apps found");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels);
        appSpinner.setAdapter(adapter);
        if (preferred >= 0) appSpinner.setSelection(preferred);
    }

    private void launchSelected() {
        int index = appSpinner.getSelectedItemPosition();
        if (index < 0 || index >= launchableApps.size()) {
            Toast.makeText(this, "Select an installed game first.", Toast.LENGTH_LONG).show();
            return;
        }
        ResolveInfo app = launchableApps.get(index);
        Intent launch = new Intent(Intent.ACTION_MAIN);
        launch.addCategory(Intent.CATEGORY_LAUNCHER);
        launch.setClassName(app.activityInfo.packageName, app.activityInfo.name);
        try { startActivity(launch); }
        catch (Exception e) { Toast.makeText(this, "Could not launch this app.", Toast.LENGTH_LONG).show(); }
    }

    private void showDeviceInfo() {
        deviceInfo.setText("Device: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
            + "\nAndroid version: " + android.os.Build.VERSION.RELEASE
            + "\nApp version: 1.0");
    }

    private void openSettings(Intent intent) {
        try { startActivity(intent); }
        catch (Exception e) { Toast.makeText(this, "Setting not available on this Android version.", Toast.LENGTH_SHORT).show(); }
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(17); t.setTypeface(null, 1);
        t.setTextColor(0xFF102A43); t.setPadding(0, dp(22), 0, dp(8));
        return t;
    }
    private TextView info(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(14); t.setTextColor(0xFF34495E);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        t.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = params(-1, -2); p.bottomMargin = dp(6);
        t.setLayoutParams(p); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(13);
        return b;
    }
    private LinearLayout.LayoutParams params(int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w,h);
        p.bottomMargin = dp(8); return p;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
