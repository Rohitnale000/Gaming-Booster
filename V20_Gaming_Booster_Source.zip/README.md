# V20 Gaming Booster (starter v1)

A lightweight Android companion app for Vivo V20. It lists installed launcher apps, attempts to preselect an app whose name contains "Cricket" and "007", and launches the selected game. It also provides safe manual setup tips and shortcuts to Android settings.

## Important limitations
- This is not a GPU overclocker or FPS unlocker.
- It cannot add physical RAM, alter the game's graphics engine, or force Android to kill other apps.
- It does not request root, accessibility, VPN, overlay, or device-admin permissions.
- Performance improvements are not guaranteed. Heat, game optimization, network conditions, and Android background limits matter.

## Build APK using GitHub Actions
1. Create a new empty GitHub repository.
2. Upload all files and folders from this project.
3. Open the repository's **Actions** tab.
4. Run **Build Android APK** (or push to main/master).
5. Open the completed workflow run and download the `V20-Gaming-Booster-debug` artifact.
6. Extract the artifact ZIP; it contains `app-debug.apk`.
7. Transfer the APK to your Vivo V20, open it, and allow installation from that source if Android asks.

This starter project has not been compiled or device-tested in this environment. The GitHub Actions workflow is provided to build it in a standard Android CI environment.
